package com.guider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuiderApplicationTests {

	@Test
	void contextLoads() {
	}

}
