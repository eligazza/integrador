import React from 'react'
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer';
const CrearCuenta = () => {
  return (
    <div>
        <Header/>
        <h1>Crear Cuenta</h1>
        <Footer/>
    </div>
  )
}

export default CrearCuenta