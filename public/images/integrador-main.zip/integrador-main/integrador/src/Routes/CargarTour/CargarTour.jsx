import React from 'react'
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer';
const CargarTour = () => {
  return (
    <div>
        <Header/>
        <h1>Cargar Tour</h1>
        <Footer/>
    </div>
  )
}

export default CargarTour