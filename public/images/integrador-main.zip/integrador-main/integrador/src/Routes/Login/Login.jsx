import React from 'react'
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer';

const Login = () => {
  return (
    <div>
        <Header/>
        <h1>Login</h1>
        <Footer/>
    </div>
  )
}

export default Login