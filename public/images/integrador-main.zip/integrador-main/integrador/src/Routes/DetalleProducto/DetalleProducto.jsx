import React from 'react'
import Header from '../../Components/Header/Header'
import Footer from '../../Components/Footer/Footer';
const DetalleProducto = () => {
  return (
    <div>
        <Header/>
        <h1>Detalle Producto</h1>
        <Footer/>
    </div>
  )
}

export default DetalleProducto