{\rtf1}
**PROYECTO INTEGRADOR CTD**

Este repositorio corresponde al proyecto final integrador para la carrera Certified Tech Developer del equipo 2, camada 5 (Oct-Dic 2023).

*Integrantes:*
- Milagros
- Víctor
- Tomás
- Elías
- Martín
- Juan Manuel
- Franco

*Definición del proyecto:*
Decidimos crear una App que te permite explorar lugares fascinantes según tus preferencias. Ya sea que te guste la naturaleza o la cultura, podrás encontrar el destino ideal para tu próxima aventura. Además, podrás elegir entre distintas opciones de recorridos, cada una con un guía especializado que te acompañará y te contará todo lo que necesitas saber sobre el lugar. Los guías son expertos en diferentes temáticas, desde historia y arte hasta ecología y deporte. Podrás elegir el tour que más te interese, según la temática y el guía, y luego contactarte con él o ella para personalizar tu experiencia aún más. Con nuestra App, no solo viajas, sino que aprendes y disfrutas al máximo.
Guider. Un viaje, una aventura.

*Bitacora:*
https://docs.google.com/presentation/d/1hUDceMl6f27AROWmG_13Gkds9I6vUwW-RZSY5qN_RQA/